var cart = '';
Page({
  data: {
    iscart: false,
    count: 1,   //商品数量默认是1  
  },
  onLoad: function (e) {
    var that = this;
    wx.request({
      url: 'http://119.28.179.110/recycle/cart/select.action',
      method: 'POST',
      data: {
        token: "eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJzdWIiOiJsb2dpbiIsImlzcyI6Inl1YW5ndW9ob25nIiwidG9rZW4iOjd9.57uHJ9WpzExv-6ERColUnQrqj8mzBEIoHAjm0IZXqXVp_LcW5eEQTRHgLyh3OubQGw8QWMo66pT9Lt-_Zt33sg"
      },
      success: function (res) {
        that.setData({
          cart: res.data.list
        })
        cart = res.data.list;
        console.log(that.data.cart);
      }
    })
    setTimeout(function (){
    console.log(cart.length)
    if(cart.length <= 0) {
      that.setData({
        iscart: 'false'
      })
    }
    else {
      that.setData({
        iscart: 'true'
      })
    }
    },1000)
    setTimeout(function () {
      var total;
      for (var i=0 ;i<cart.length; i++){
        total = cart[i].garbage.category.cprice * cart[i].weight;
      }
      that.setData({
        total: total
      })
    },2000)
  },
  cleanAll() {
    wx.request({
      url: 'http://119.28.179.110/recycle/cart/clear.action',
      data:{
        token: App.token
      },
      success: function(res){
        wx.showToast({
          title: '清空成功',
          duration: 1500
        })
      }
    })
  },
  delGoods(e) {
    console.log(e)
    wx.request({
      url: 'http://119.28.179.110/recycle/cart/delete.action',
      method: 'POST',
      data:{
        gid: e.currentTarget.id
      }, 
      success: function(res) {
        wx.showToast({
          title: '删除成功',
          duration: 1500
        })
      },
    })
    wx.navigateTo({
      title: "goback",
      url: '../home/home'
    })
  },
  toBuy() {
    wx.showToast({
      title: '去结算',
      icon: 'success',
      duration: 3000
    });
    this.setData({
      showDialog: !this.data.showDialog
    });
  },
})